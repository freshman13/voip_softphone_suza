var user = {
    //  User Name
    "User" : "1003",
    //  Password
    "Pass" : "finance",
    //  Auth Realm
    "Realm"   : "10.4.1.3",
    // Display Name
    "Display" : "Gob Bleuth",
    // WebSocket URL
    "WSServer"  : "wss://10.4.1.3:8089"
};
